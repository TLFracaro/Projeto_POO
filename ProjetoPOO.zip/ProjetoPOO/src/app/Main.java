package app;

import view.TelaLogin;

public class Main {

	public static void main(String[] args) {
		TelaLogin login = new TelaLogin();
	}

}
