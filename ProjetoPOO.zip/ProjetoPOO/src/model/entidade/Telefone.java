package model.entidade;

public record Telefone(
		String[] telefone
		) {
}
