package model.entidade;

public record Holerite() {

}
