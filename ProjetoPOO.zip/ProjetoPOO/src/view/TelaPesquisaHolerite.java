package view;

public class TelaPesquisaHolerite {
	
	TelaPesquisaHolerite(){
		
	}
	
}
