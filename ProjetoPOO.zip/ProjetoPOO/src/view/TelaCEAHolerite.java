package view;

public class TelaCEAHolerite {
	
	TelaCEAHolerite(){
		
	}
}
