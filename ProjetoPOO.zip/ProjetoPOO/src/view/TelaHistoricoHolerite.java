package view;

public class TelaHistoricoHolerite {
	
	TelaHistoricoHolerite(){
		
	}
	
}
