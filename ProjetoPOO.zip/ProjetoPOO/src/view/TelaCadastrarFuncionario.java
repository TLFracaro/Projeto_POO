package view;

public class TelaCadastrarFuncionario {
	
	TelaCadastrarFuncionario(){
		
	}
	
}
