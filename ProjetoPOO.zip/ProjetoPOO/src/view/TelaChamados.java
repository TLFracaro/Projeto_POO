package view;

public class TelaChamados {
	
	TelaChamados(){
		
	}
	
}
